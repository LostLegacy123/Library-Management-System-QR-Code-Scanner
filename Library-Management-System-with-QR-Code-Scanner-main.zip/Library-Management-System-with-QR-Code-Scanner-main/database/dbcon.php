<?php
$con = mysqli_connect('localhost','root','','lms')or die(mysqli_error());
?>