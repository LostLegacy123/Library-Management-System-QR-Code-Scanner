<?php  include('include/header.php'); ?>
<div class="row justify-content-center">
<div id="content-wrapper" class="d-flex flex-column">
    <div id="content">
    <div class="contatin-fluid">
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 ml-5 text-gray-800">Book Information</h1>
            <a href="edit_profile.php" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm mr-5"><i
                    class="fas fa-download fa-sm text-white-50"></i> Edit Profile</a>
        </div>
            <div class="card">
                <div class="card-body">
                    <ul>
                        <li>Book Image:
                            <img src="img/">
                        </li>
                        <li>Title:</li>
                        <li>Author:</li>
                        <li>Copies:</li>
                        <li>Category:</li>
                        <li>Status:</li>
                    </ul>
                </div>
            </div>
    </div>
</div>
</div>
</div>
